#include"��ͷ.h"
void storeString(SString *S, const char* str) {
    int i;
    for (i = 0; str[i] != '\0'; i++) {
        S->ch[i + 1] = str[i];
    }
    S->length = i;
}
int main() {
	//test();
     SString S;
     SString T;
    const char* str = "hello,world";
    const char* str2 = "llo";
    storeString(&S, str);
    storeString(&T, str2);
    int index = index1(S, T);
    printf("index = %d", index);
  
    /*printf("String length: %d\n", S.length);*/
	return 0;
}
