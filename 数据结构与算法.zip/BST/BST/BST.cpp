#include"BST.h"
void Init(BSTree* bst) {
	bst->root = NULL;
}
BOOL InsertNode(BSTreeNode** t, T x) {
    if (*t == NULL) {
        *t = (BSTreeNode*)malloc(sizeof(BSTreeNode));
        assert(*t != NULL);
        (*t)->data = x;
        (*t)->LeftChild = NULL;
        (*t)->RightChild = NULL;
    }
    else if ((*t)->data > x) {
        InsertNode(&((*t)->LeftChild), x);
    }
    else if ((*t)->data < x) {
        InsertNode(&((*t)->RightChild), x);
    } 
    else {
        return FALSE;
    }
    return TRUE;
}
T Min(BSTreeNode* t) {
    while (t->LeftChild != NULL) {
        t = t->LeftChild;
    }
    return t->data;
}
T Min(BSTree* bst) {
    assert(bst->root != NULL);
    return Min(bst->root);
}
T Max(BSTreeNode* t) {
    while (t->RightChild != NULL) {
        t = t->RightChild;
    }
    return t->data;
}
T Max(BSTree* bst) {
    assert(bst->root != NULL);
    return Max(bst->root);
}
void Sort(BSTreeNode* t) {
    if (t != NULL) {
        Sort(t->LeftChild);
        printf("%d ", t->data);
        Sort(t->RightChild);
  }
}
//�ҵ�ָ���Ľ��-�� 
//
BSTreeNode* Search(BSTreeNode* t, T key) {
    if (t == NULL) {
        return NULL;
    }
    if (key = t->data) {
        return t;
    }
    else if(key < t->data){
        return Search(t->LeftChild, key);
    }else{
        return Search(t->RightChild, key);
    }
}
void MakeEmptyBSTree(BSTree* bst) {

}
//�Ż�
BOOL RemoveBSTree(BSTreeNode** t, T key) {
    if (*t == NULL) {
        return FALSE;
    }
    if (key < (*t)->data) {
        return RemoveBSTree(&((*t)->LeftChild), key);
    }
    else if (key > (*t)->data) {
        return RemoveBSTree(&((*t)->RightChild), key);
    }
    else {//��ȵ���� ���ֺü������ 1 �ҵ��Ľ�����û�����Һ��ӣ�ֱ��ɾ����
        BSTreeNode* p = NULL;
        if((*t)->LeftChild!=NULL&&(*t)->RightChild!=NULL){
            p = (*t)->RightChild;
            while (p->LeftChild != NULL) {
                p = p->LeftChild;
            }
            (*t)->data = p->data;
            RemoveBSTree(&(*t)->RightChild, p->data);
        }
        else {
            if ((*t)->LeftChild == NULL) {
                p = *t;
                *t = (*t)->RightChild;
            }
            else {
                p = *t;
                *t = (*t)->LeftChild;
            }
            free(p);
            p = NULL;
        }
    }
    return TRUE;
}
//BOOL RemoveBSTree(BSTreeNode** t, T key) {
//    if (*t == NULL) {
//        return FALSE;
//    }
//    if (key < (*t)->data) {
//        return RemoveBSTree(&((*t)->LeftChild), key);
//    }
//    else if (key > (*t)->data) {
//        return RemoveBSTree(&((*t)->RightChild), key);
//    }
//    else {//��ȵ���� ���ֺü������ 1 �ҵ��Ľ�����û�����Һ��ӣ�ֱ��ɾ����
//        BSTreeNode* p = NULL;
//        if ((*t)->LeftChild == NULL && (*t)->RightChild == NULL) {
//            free(*t);
//            *t = NULL;
//        }
//        else if ((*t)->LeftChild != NULL && (*t)->RightChild == NULL) {
//            p = *t;
//            *t = (*t)->LeftChild;
//            free(*t);
//            p = NULL;
//        }
//        else if ((*t)->LeftChild == NULL && (*t)->RightChild != NULL) {
//            p = *t;
//            *t = (*t)->RightChild;
//            free(p);
//            p = NULL;
//        }
//        else {
//            p = (*t)->RightChild;
//            while (p->LeftChild != NULL) {
//                p = p->LeftChild;
//            }
//            (*t)->data = p->data;
//            RemoveBSTree(&(*t)->RightChild, p->data);
//        }
//    }
//    return TRUE;
//}
void MakeEmptyBSTree(BSTreeNode** t) {
    if (*t == NULL) {
        return;
    }
    MakeEmptyBSTree(&(*t)->LeftChild);
    MakeEmptyBSTree(&(*t)->RightChild);
    free(*t);
    *t = NULL;
}
