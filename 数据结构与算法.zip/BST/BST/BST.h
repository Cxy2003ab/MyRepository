#include<stdio.h>
#include<stdlib.h>
#include<malloc.h>
#include<assert.h>
#define T int
#define BOOL int
#define TRUE 1
#define FALSE 0
//�����
typedef struct BSTreeNode {
    T data;
    struct BSTreeNode* LeftChild;
    struct BSTreeNode* RightChild;
} BSTreeNode;

typedef struct BSTree {
    BSTreeNode* root;
} BSTree;
void Init(BSTree*bst);
BOOL InsertNode(BSTreeNode** t, T x);
T Min(BSTreeNode* t);
T Min(BSTree* bst);
T Max(BSTreeNode* t);
T Max(BSTree* bst);
void Sort(BSTreeNode* t);
BOOL RemoveBSTree(BSTreeNode** t, T key);
BOOL RemoveBSTree(BSTree* bst, T key);
BSTreeNode* Search(BSTreeNode* t, T key);
void MakeEmptyBSTree(BSTree* bst);