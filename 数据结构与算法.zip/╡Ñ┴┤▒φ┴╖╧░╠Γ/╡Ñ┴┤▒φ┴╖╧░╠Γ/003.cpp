#include <stdio.h>
#include <stdlib.h>

typedef struct LinkList {
    int data;
    struct LinkList* next;
} LinkList;

void print(LinkList* L) {
    LinkList* p = L->next;
    while (p != NULL) {
        printf("%d ", p->data);
        p = p->next;
    }
    printf("\n");
}

void Init(LinkList*& st) {
    st = NULL; // ʹ�õ����ȺŽ��и�ֵ����
}

void push(LinkList*& st, int x) {
    LinkList* p = (LinkList*)malloc(sizeof(LinkList));
    p->data = x;
    p->next = st; // ���½ڵ��nextָ��ָ��ǰջ���ڵ�
    st = p;
}

void pop(LinkList*& st) {
    if (st == NULL) {
        printf("stack is empty!\n");
        return;
    }
    LinkList* p = st;
    st = st->next;
    free(p); // �ͷŽڵ���ڴ�
}

bool IsEmpty(LinkList* st) {  // ����Ҫ��������
    return st == NULL;  // ֱ�ӷ����жϽ��
}

void print1(LinkList* L, LinkList*& st) {
    LinkList* p = L->next;
    while (p != NULL) {
        push(st, p->data);
        p = p->next;
    }
    while (!IsEmpty(st)) {
        printf("%d ", st->data);
        pop(st);
    }
    printf("\n");
}

int main() {
    LinkList L;
    LinkList* st = NULL;  // ��ʼ��ջΪ��
    Init(st);
    L.next = NULL;

    LinkList* p = (LinkList*)malloc(sizeof(LinkList));
    p->data = 10;
    p->next = NULL;

    LinkList* r = (LinkList*)malloc(sizeof(LinkList));
    r->data = 9;
    r->next = NULL;

    LinkList* k = (LinkList*)malloc(sizeof(LinkList));
    k->data = 8;
    k->next = NULL;

    LinkList* t = (LinkList*)malloc(sizeof(LinkList));
    t->data = 7;
    t->next = NULL;

    L.next = p;
    p->next = r;
    r->next = k;
    k->next = t;

    print(&L);
    print1(&L, st);

    return 0;
}
