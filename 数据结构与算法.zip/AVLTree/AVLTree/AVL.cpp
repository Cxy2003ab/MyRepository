#include"AVL.h"
void Init(AVLTree* avl) {
	avl->root == NULL;
}
AVLNode* buyNode(int x) {
	AVLNode* p = NULL;
	if (p == NULL) {
		p->data = x;
		p->LChild == NULL;
		p->RChild == NULL;
	}
	return p;
}
BOOL insertNode(AVLNode*& t, int x) {
	AVLNode* p = t;
	AVLNode* parent = NULL;
	p = buyNode(x);
	while (p != NULL) {

	}
}
AVLNode* insertNode(AVLTree* t,int x) {
	return t->root;
}