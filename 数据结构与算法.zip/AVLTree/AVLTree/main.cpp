#include"AVL.h"
int main() {
	AVLTree avl;
	Init(&avl);
	int x;
	insertNode(&avl, x);
	return 0;
}