#include<stdio.h>
#include<malloc.h>
#include"LinkStack.h"
#define ElemType int
#define BOOL int
#define False 0
#define True 1
typedef struct AVLNode{
	ElemType data;
	AVLNode* LChild;
	AVLNode* RChild;
	int      bf;//ƽ������
}AVLNode;
typedef struct AVLTree {
	AVLNode* root;
}AVLTree;
void Init(AVLTree* t);
AVLNode* buyNode(int x);
BOOL insertNode(AVLNode* t, int x);
AVLNode* insertNode(AVLTree* t, int x);