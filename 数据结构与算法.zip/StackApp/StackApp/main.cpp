#include"SeqStack.h"
//bool Cheak(char* str) {
//	SeqStack st;
//	int v;
//	while (*str != '\0') {
//		if (*str == '[' || '{' || '(') {//�����ž���ջ
//			Push(&st, *str);
//		}
//		else if (*str == ']') {
//			GetTop(&st, &v);//��ȡջ��Ԫ��
//			if (v == '[') {
//				Pop(&st);
//			}
//		}
//		else if (*str == ')') {
//			GetTop(&st, &v);//��ȡջ��Ԫ��
//			if (v == '(') {
//				Pop(&st);
//			}
//		}
//		else if (*str == '}') {
//			GetTop(&st, &v);//��ȡջ��Ԫ��
//			if (v == '{') {
//				Pop(&st);
//			}
//		}
//		++str;
//	}
//	return IsEmpty(&st);//���ջ�л���Ԫ�ؾ��ǻ�û������û��ƥ����
//}
void convert(SeqStack* st, int x) {//����ת��
	int value = x;
	while (value) {
		Push(st, value % 2);
		value = value / 2;
	}
	//Show(st);
	int v;
	while (!IsEmpty(st)) {
		GetTop(st, &v);
		Pop(st);
		printf("%d",v);
	}
}
int main() {
	SeqStack st;
	InitStack(&st);
	int x = 8421;
	convert(&st, x);
	return 0;
}
//int main() {
//	  char str[] = "[()[][]]{}{))";
//	bool flag = Cheak(str);
//	if (flag) {
//		printf("OK\n");
//	}
//	else {
//		printf("Error!\n");
//	}
//	return 0;
//}