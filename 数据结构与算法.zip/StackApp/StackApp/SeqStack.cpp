#include"SeqStack.h"
void InitStack(SeqStack* s) {
	s->base = (ElemType*)malloc(sizeof(ElemType) * STACK_INIT_SIZE);//������8����ַ�����Ŀռ䣨�൱�����飩
	s->capacity = STACK_INIT_SIZE;
	s->top = 0;
}
bool IsFull(SeqStack* s) {
	if (s->top == s->capacity) {
		return true;
	}
	return false;
}
bool IsEmpty(SeqStack* s) {
	if (s->top == 0) {
		return true;
	}
	return false;
}

void Push(SeqStack* s, ElemType x) {
	if (IsFull(s) && !inc(s)){
		printf("ջ�ռ�������\n");
	}
	s->base[s->top++] = x;
	return;
}
void Pop(SeqStack* s) {
	if (IsEmpty(s)) {
		printf("ջ����Ԫ��\n");
		return;
	}
	s->top--;
}
bool GetTop(SeqStack* s, ElemType* v) {
	if (IsEmpty(s)) {
		printf("ջ����Ԫ��\n");
		return false;
	}
	*v = s->base[s->top - 1];
	return true;
}
void Show(SeqStack* s) {
	while (s->top > 0) {
		s->top--;
		printf("%d ", s->base[s->top]);
	}
	printf("\n");
}
int Length(SeqStack* s) {
	return s->top;
}
void Clear(SeqStack* s) {
	s->top = 0;
}
bool inc(SeqStack* s) {
	ElemType* newbase = (ElemType*)realloc(s->base, sizeof(ElemType) * (s->capacity + Inc_STACK_SIZE));
	if (newbase == NULL) {
		printf("�ڴ�ռ䲻�㣬�޷�����ռ䡣\n");
		return false;
	}
	s->base = newbase;
	s->capacity += Inc_STACK_SIZE;
	return true;
}