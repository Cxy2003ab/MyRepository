#include"LinkStack.h"
int main() {
	LinkStack st;
	InitStack(&st);

	for (int i = 1; i <= 5; ++i) {
		push(&st, i);
	}
	print(st);
	//��ջ����
	pop(&st);
	print(st);
	return 0;
}