#include"AVLStack.h"
void InitStack(LinkStack* s) {
	*s = NULL;
	return;
}
void push(LinkStack* s, ElemType x) {
	if (*s == NULL) {
		*s = (StackNode*)malloc(sizeof(StackNode));
		assert(*s != NULL);
		(*s)->data = x;
		(*s)->next = NULL;
	}
	else {
		StackNode* p = (StackNode*)malloc(sizeof(StackNode));
		assert(p != NULL);//���p��㴴���ɹ��Ļ�
		p->next = *s;
		p->data = x;
		*s = p;
	}
}
//Ҳ���ǽ���һ������ɾ��
void pop(LinkStack* s) {
	if (*s == NULL) {
		return;
	}
	StackNode* p = *s;
	*s = p->next;
	free(p);
	p = NULL;
}
//��ӡ���
void print(LinkStack s) {
	StackNode* p = s;
	while (p != NULL) {
		printf("%d ", p->data);
		p = p->next;
	}
	printf("\n");
}