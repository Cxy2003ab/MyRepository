#include"AVL.h"
#include<stdio.h>
#include<malloc.h>
#include<assert.h>
#define ElemType int
typedef struct StackNode {
	ElemType data;
	struct StackNode* next;
}StackNode;
typedef struct StackNode* LinkStack;//����������ջ����
void InitStack(LinkStack* s);
void push(LinkStack* s, ElemType x);
void pop(LinkStack* s);
void print(LinkStack s);