#include<stdio.h>
#include<stdbool.h>
#define MAXSIZE 100
typedef struct {
	char data;
	int parent;
}Node;
typedef struct {
	Node nodes [MAXSIZE];//�������
	int n;//�����
}Ptree;
void InitPtree(Ptree* tree);
int CreateNode(Ptree* tree, char data, int parent);
int main() {
	Ptree tree;
	InitPtree(&tree);
	int A = CreateNode(&tree, 'A', -1);
	int B = create_node(&tree, 'B', A);
	int C = create_node(&tree, 'C', A);
	int D = create_node(&tree, 'D', B);
	int E = create_node(&tree, 'E', B);
	int F = create_node(&tree, 'F', C);
	int G = create_node(&tree, 'G', C);


	return 0;
}
//int find(Ptree*tree, int parent) {
	Node* node;
	
//}

void InitPtree(Ptree* tree) {
	tree->n = 0;
}
int CreateNode(Ptree* tree, char data, int parent) {
	if (tree->n >= MAXSIZE) {
		//���Ѿ�����
		printf("The tree is full!");
		return -1;
	}
	Node node = { data,parent };
	tree->nodes[tree->n] = node;
	tree->n++;
	return tree->n - 1;
}