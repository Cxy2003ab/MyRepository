////Ŀ�ģ�����һ�����ӣ������������� 1 2 3 4 5 6
//#include <stdio.h>
//#include <stdio.h>
//#include <stdlib.h>
//
//typedef struct Node {
//    int data;
//    struct Node* next;
//} Node, * linklist;
//
//typedef struct EnQueueList {
//    Node* front;
//    Node* rear;
//} EnQueueList, * EnQue;
//
//void Init(EnQue* L) {
//    (*L) = (EnQue)malloc(sizeof(EnQueueList));
//    (*L)->front = (*L)->rear = (Node*)malloc(sizeof(Node));
//    (*L)->front->next = NULL;
//}
//
//void EnQueue(EnQue Q, int e) {
//    linklist p = (linklist)malloc(sizeof(Node));
//    p->data = e;
//    p->next = NULL;
//    Q->rear->next = p;
//    Q->rear = p;
//}
//
//void OutQueue(EnQue Q, int* e) {
//    if (Q->front == Q->rear) {
//        return;
//    }
//    linklist p = Q->front->next;
//    *e = p->data;
//    Q->front->next = p->next;
//    free(p);
//    if (Q->rear == p) {//���p�����һ�����
//        Q->rear = Q->front;
//    }
//}
//
//void print(EnQue Q) {
//    linklist p;
//    p = Q->front->next;
//    while (p != NULL) {
//        printf("%d ", p->data);
//        p = p->next;
//    }
//    printf("\n");
//}
//
//int main() {
//    EnQue L;
//    int i, data, e;
//    Init(&L);
//    for (i = 1; i <= 5; i++) {
//        scanf_s("%d", &data);
//        EnQueue(L, data);
//    }
//    OutQueue(L, &e);
//    printf("���ӵĵ�һ��ֵΪ%d\n", e);
//    printf("�������г��ӵ�ֵΪ:\n");
//    print(L);
//    return 0;
//}
