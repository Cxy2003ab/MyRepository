////Ŀ�ģ�����һ���� ����α������� �����A (B C) (D E F G) H
//#include <stdio.h>
//#include <stdlib.h>
//
//typedef struct BiTNode {
//    char ch;
//    struct BiTNode* lchild;
//    struct BiTNode* rchild;
//} BiTNode, * BiTree;
//
//void Init(BiTree* T) {
//    *T = (BiTree)malloc(sizeof(BiTNode));
//    (*T)->ch = 'A';
//    (*T)->lchild = NULL;
//    (*T)->rchild = NULL;
//}
//
//int InsertLeft(BiTree T, char ch) {
//    BiTree p = (BiTree)malloc(sizeof(BiTNode));
//    if (p == NULL) {
//        return -1;
//    }
//    p->ch = ch;
//    p->lchild = NULL;
//    p->rchild = NULL;
//    T->lchild = p;
//    return 1;
//}
//
//int InsertRight(BiTree T, char ch) {
//    BiTree p = (BiTree)malloc(sizeof(BiTNode));
//    if (p == NULL) {
//        return -1;
//    }
//    p->ch = ch;
//    p->lchild = NULL;
//    p->rchild = NULL;
//    T->rchild = p;
//    return 1;
//}
////���ٶ�����
//void delete(BiTree T) {
//    if (T == NULL) {
//        return;
//    }
//    delete(T->lchild);
//    delete(T->rchild);
//    free(T);
//}
//void PreOrderTree(BiTree T) {
//    if (T == NULL) {
//        return;
//    }
//    char ch = T->ch;
//    printf("%c ", ch);
//    PreOrderTree(T->lchild);
//    PreOrderTree(T->rchild);
//}
//int main() {
//    BiTree T;
//    Init(&T);
//    InsertLeft(T, 'B');
//    InsertRight(T, 'C');
//    InsertLeft(T->lchild, 'D');
//    InsertRight(T->lchild, 'E');
//    InsertLeft(T->rchild, 'F');
//    InsertRight(T->rchild, 'G');
//    InsertLeft(T->lchild->lchild, 'H');
//    printf("�����������\n");
//    PreOrderTree(T);
//    delete(T);
//    return 0;
//}
//
