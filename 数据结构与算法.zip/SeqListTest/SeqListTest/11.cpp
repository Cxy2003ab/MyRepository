//#include<stdio.h>
//#include<malloc.h>
//int SearchMiddle(int A[], int B[],int n) {
//	int i, j, k;
//	int L = 2 * n;
//	int* arr = (int*)malloc(sizeof(int) * L);
//	for (i = 0,j = 0, k = 0; i < n && j < n && k < L; k++) {
//		if (A[i] <= B[j]) {
//			arr[k] = A[i++];
//		}
//		else {
//			arr[k] = B[j++];
//		}
//	}
//	return arr[L / 2];
//}
//int main() {
//	//A��B����һ��
//	int A[] = { 11,13,15,17,19 };
//	int B[] = { 2,4,6,8,20 };
//	int n = sizeof(A) / sizeof(A[0]);
//	int MiddleData = SearchMiddle(A, B,n);
//	printf("A��B����λ��Ϊ%d\n", MiddleData);
//	return 0;
//}