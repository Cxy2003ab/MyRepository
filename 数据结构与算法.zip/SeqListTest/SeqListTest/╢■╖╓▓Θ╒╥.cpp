//���ֲ���
#include<stdio.h>
int Find(int arr[], int key, int n) {
	//�ҵ��˾ͷ��������±꣬û�ҵ��ͷ���-1��
	int low = 0;
	int high = n - 1;
	while (low <= high) {
		int mid = (low + high) / 2;
		if (arr[mid] == key) {
			return mid;
		}
		if (arr[mid] < key) {
			low = mid + 1;
		}
		else {
			high = mid - 1;
		}
	}
	return -1;
}
int main() {
	int arr[] = { 10,28,37,46,55,66,78,89,99 };
	int n = sizeof(arr) / sizeof(int);
	int key = 55;
	int result = Find(arr, key,n);
	printf("result=%d\n", result);
}