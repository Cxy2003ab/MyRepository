//#include <stdio.h>
//#include <stdlib.h>
//#include <stdbool.h>
//#define DATA_SIZE 5
//#define ElemType int
//
//typedef struct SeqList {
//    ElemType* base; // �������ַ
//    int size;       // �����С
//} SeqList;
//
//void init(SeqList* L) {
//    L->base = (ElemType*)malloc(sizeof(ElemType) * DATA_SIZE);
//    L->size = DATA_SIZE;
//}
//
//bool delet(SeqList* L, ElemType* x) {
//    if (L->size == 0) {
//        return false;
//    }
//    int min = L->base[0];
//    int index = 0;
//    for (int i = 0; i < L->size; i++) {
//        if (min > L->base[i]) {
//            min = L->base[i];
//            index = i;
//        }
//    }
//    *x = min; // ������Сֵ
//    L->base[index] = L->base[L->size - 1];
//    L->size--;
//    return true;
//}
//
//int main() {
//    SeqList L;
//    ElemType x;
//    init(&L);
//    for (int i = 4; i >= 0; i--) {
//        L.base[i] = i + 1;
//    }
//    if (delet(&L, &x)) {
//        printf("Deleted min value: %d\n", x);
//    }
//    else {
//        printf("The list is empty.\n");
//    }
//
//    free(L.base); // �ͷŶ�̬������ڴ�
//    return 0;
//}
