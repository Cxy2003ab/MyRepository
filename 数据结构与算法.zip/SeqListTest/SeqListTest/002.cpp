//#include <stdio.h>
//#include <stdlib.h>
//#include <stdbool.h>
//#define DATA_SIZE 5
//#define ElemType int
//
//typedef struct SeqList {
//    ElemType* base; // �������ַ
//    int size;       // �����С
//} SeqList;
//
//void init(SeqList* L) {
//    L->base = (ElemType*)malloc(sizeof(ElemType) * DATA_SIZE);
//    L->size = DATA_SIZE;
//}
////��һ�ַ���
//bool reverse(SeqList* L) {
//    ElemType temp;//������������
//    if (L->size == 0) {
//        return false;
//    }
//    int length = L->size;
//    for (int i = 0; i <= length / 2; i++) {
//        temp = L->base[i];
//        L->base[i] = L->base[length - i-1];
//        L->base[length - i - 1] = temp;
//    }
//    return true;
//}
////�ڶ��ַ���
//bool reverseArray(SeqList* L, int left, int right) {
//    ElemType temp;//������������
//    if (L->size == 0) {
//        return false;
//    }
//    int length = L->size;
//    while (left < right) {
//        temp = L->base[left];
//        L->base[left] = L->base[right];
//        L->base[right] = temp;
//        left++;
//        right++;
//    }
//    return true;
//}
//void show(SeqList* L) {
//    for (int i = 0; i < L->size; i++) {
//        printf("%d ", L->base[i]);
//    }
//    printf("\n");
//}
//int main() {
//    SeqList L;
//    ElemType x;
//    init(&L);
//    for (int i = 4; i >= 0; i--) {
//        L.base[i] = i + 1;
//    }
//    printf("��תǰ\n");
//    show(&L);
//    reverse(&L);
//    printf("��ת��\n");
//    show(&L);
//}