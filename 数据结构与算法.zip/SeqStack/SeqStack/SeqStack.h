#include<stdio.h>
#include<malloc.h>
#define ElemType char
#define Inc_STACK_SIZE 10
#define STACK_INIT_SIZE 8
typedef struct SeqStack {
	ElemType* base;//����ַ
	int		capacity;//ջ����
	int		top;//ջԪ�ص�λ��
}SeqStack;

void InitStack(SeqStack* s);
bool IsFull(SeqStack* s);
bool IsEmpty(SeqStack* s);

void Push(SeqStack* s, ElemType x);
void Pop(SeqStack* s);
bool GetTop(SeqStack* s, ElemType* v);
void Show(SeqStack* s);
int Length(SeqStack* s);
void Clear(SeqStack* s);
bool inc(SeqStack* s);