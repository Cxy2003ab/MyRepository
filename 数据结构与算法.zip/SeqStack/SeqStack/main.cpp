#include"SeqStack.h"
int main() {
	SeqStack st;
	InitStack(&st);

	//��ջ
	for (int i = 1; i <= 5; i++) {
		Push(&st, i);
	}
	Show(&st);
	return 0;
}